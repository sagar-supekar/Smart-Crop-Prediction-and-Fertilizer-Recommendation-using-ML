from django.contrib import admin
from app.models import Crop_Details

# Register your models here.
admin.site.register(Crop_Details)